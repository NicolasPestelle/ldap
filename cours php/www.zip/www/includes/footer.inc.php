﻿</div>
          
          <nav class="span4">
            <h2>Menu</h2>
            
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="article.php">Rédiger un article</a></li>
            </ul>
            
          </nav>
        </div>
        
      </div>

      <footer>
        <p>&copy; Samuel FIQUET 2015</p>
      </footer>

    </div>

  </body>
</html>
