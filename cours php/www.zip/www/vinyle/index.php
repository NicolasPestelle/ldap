<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Artisteer v3.0.0.39952
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Accueil</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />


    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->

    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
</head>
<body>
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-header">
    <div class="art-header-wrapper">
    <div class="art-header-inner">
        <div class="art-headerobject"></div>
        <div class="art-logo">
                        </div>
    </div>
    </div>
    </div>
    <div class="cleared reset-box"></div>
<div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
<div class="art-nav-wrapper">
<div class="art-nav-inner">
	<ul class="art-hmenu">
		<li>
			<a href="#" class="active"><span class="l"></span><span class="r"></span><span class="t">Accueil</span></a>
		</li>	
		<li>
			<a href="#"><span class="l"></span><span class="r"></span><span class="t">News</span></a>
			<ul>
				<li>
                    <a href="#">Top 10</a>
			<ul>
				<li>
                    <a href="#">Menu Sous-élément 1</a>

                </li>
				<li>
                    <a href="#">Menu Sous-élément 2</a>

                </li>
				<li>
                    <a href="#">Menu Sous-élément 3</a>

                </li>
			</ul>

                </li>
				<li>
                    <a href="#">2008</a>

                </li>
				<li>
                    <a href="#">January</a>

                </li>
			</ul>
		</li>	
		<li>
			<a href="#"><span class="l"></span><span class="r"></span><span class="t">Menu Element</span></a>
		</li>	
	</ul>
</div>
</div>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-sheet">
        <div class="art-sheet-body">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">
                    Text, <a href="#" rel="bookmark" title="Permanent Link to this Post">Link</a>, <a class="visited" href="#" rel="bookmark" title="Visited Hyperlink">Visited</a>, <a class="hovered" href="#" rel="bookmark" title="Hovered Hyperlink">Hovered</a>
                                        </h2>
                    <div class="cleared"></div>
                                    </div>
                                                <div class="art-postheadericons art-metadata-icons">
                    <img src="images/postdateicon.png" width="18" height="18" alt="" />
					<a href="inscription.php">Inscription</a>
					<a href="login.php">Connexion</a>
mercredi 5 novembre 2008
                     | <img src="images/postauthoricon.png" width="18" height="18" alt="" />
                    Author <a href="#" title="Posts by Admin">Admin</a>                     | <img src="images/postediticon.png" width="15" height="18" alt="" />
                    <a href="#" title="Edit">Edit</a>                </div>
                <div class="art-postcontent">

<img src="images/preview.jpg" alt="an image" style="float:left;" /><img src="./images/WP.png" alt="an image" style="float:left;border:0;margin: 1em 1em 0 0;" />
        <p>Lorem <sup>superscript</sup> dolor <sub>subscript</sub> amet, consectetuer adipiscing <a href="#" title="link">link</a>, <a class="visited" href="#" title="visited link">visited link</a>,
 <a class="hover" href="#" title="hovered link">hovered link</a> consectetuer adipiscing elit.
 Quisque sed felis. Aliquam sit amet felis. Mauris semper, velit
 semper laoreet dictum, quam diam dictum urna, nec placerat elit nisl <a href="#" title="one more link">one more link</a> in quam. Etiam
 augue pede, molestie eget, rhoncus at, convallis ut, eros.</p>
<p>Aliquam pharetra. Nulla in tellus eget odio sagittis blandit.Maecenas at nisl. Nullam
 lorem mi, eleifend a, fringilla vel, semper at, ligula. Mauris eu wisi. Ut ante
 dui, aliquet nec, congue non, accumsan sit amet, lectus. Mauris et mauris. Duis
 sed massa id mauris pretium venenatis. Suspendisse cursus velit vel ligula. Mauris
 elit.</p>
 <p>Aliquam pharetra. Nulla in tellus eget odio sagittis blandit.Maecenas at nisl. Nullam
 lorem mi, eleifend a, fringilla vel, semper at, ligula. Mauris eu wisi. Ut ante
 dui, aliquet nec, congue non, accumsan sit amet, lectus. Mauris et mauris. Duis
 sed massa id mauris pretium venenatis. Suspendisse cursus velit vel ligula. Mauris
 elit.</p>

                </div>
                <div class="cleared"></div>
                                <div class="art-postfootericons art-metadata-icons">
                    <img src="images/postcategoryicon.png" width="18" height="18" alt="" />
                    Category: No Category                     | <img src="images/posttagicon.png" width="18" height="18" alt="" />
                    Tags: <a href="#" title="link">link</a>, <a href="#" title="visited link" class="visited">visited</a>, <a href="#" title="hovered link" class="hover">hovered</a>                     | <img src="images/postcommentsicon.png" width="18" height="18" alt="" />
                    <a href="#" title="Comments">No Comments »</a>
                </div>
                </div>

		<div class="cleared"></div>
    </div>
</div>
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">
                    <a href="#" title="Permanent Link to this Post">Worth A Thousand Words</a>
                                        </h2>
                    <div class="cleared"></div>
                                    </div>
                                                <div class="art-postheadericons art-metadata-icons">
                    <img src="images/postdateicon.png" width="18" height="18" alt="" />
jeudi 11 septembre 2008
                     | <img src="images/postauthoricon.png" width="18" height="18" alt="" />
                    Author <a href="#" title="Posts by Admin">Admin</a>                     | <img src="images/postediticon.png" width="15" height="18" alt="" />
                    <a href="#" title="Edit">Edit</a>                </div>
                <div class="art-postcontent">

<h1>Heading 1</h1>
<h2>Heading 2</h2>
<h3>Heading 3</h3>
<h4>Heading 4</h4>
<h5>Heading 5</h5>
<h6>Heading 6</h6>
<p>Lorem <sup>superscript</sup> dolor <sub>subscript</sub> amet, consectetuer adipiscing
 elit, <a href="#" title="test link">test link</a>. Nullam dignissim convallis est.
 Quisque aliquam. <cite>cite</cite>. Nunc iaculis suscipit dui. Nam sit amet sem.
 Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent
 mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim
 diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla
 nonummy. <acronym title="National Basketball Association">NBA</acronym> Mauris a
 ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi
 imperdiet augue quis tellus.<abbr title="Avenue">AVE</abbr></p>
<h3>List</h3>
<ul>
 <li>List Item 1</li>
 <li>List Item 2</li>
 <li>List Item 3</li>
</ul>
<h3>Quote</h3>
<blockquote>
 <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit.”<br />-Blockquote</p>
</blockquote>
<h3>Table</h3><table border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<th>Header</th>
<th>Header</th>
<th>Header</th>
</tr>
<tr>
<td>Data</td>
<td>Data</td>
<td>Data</td>
</tr>
<tr>
<td>Data</td>
<td>Data</td>
<td>Data</td>
</tr>
<tr>
<td>Data</td>
<td>Data</td>
<td>Data</td>
</tr>
</tbody></table>
<br />

                </div>
                <div class="cleared"></div>
                                <div class="art-postfootericons art-metadata-icons">
                    <img src="images/postcategoryicon.png" width="18" height="18" alt="" />
                    Category: No Category                     | <img src="images/posttagicon.png" width="18" height="18" alt="" />
                    Tags: <a href="#" title="link">link</a>, <a href="#" title="visited link" class="visited">visited</a>, <a href="#" title="hovered link" class="hover">hovered</a>                     | <img src="images/postcommentsicon.png" width="18" height="18" alt="" />
                    <a href="#" title="Comments">No Comments »</a>
                </div>
                </div>

		<div class="cleared"></div>
    </div>
</div>

                      <div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="art-footer">
        <div class="art-footer-t"></div>
        <div class="art-footer-b"></div>
        <div class="art-footer-body">
            <div class="art-footer-center">
                <div class="art-footer-wrapper">
                    <div class="art-footer-text">
                        <a href="#" class="art-rss-tag-icon" title="RSS"></a>
                        <p><a href="#">Link1</a> | <a href="#">Link2</a> | <a href="#">Link3</a></p><p>Copyright © 2015. All Rights Reserved.</p>
                        <div class="cleared"></div>
                        <p class="art-page-footer">Powered by <a href="http://wordpress.org/">WordPress</a> and <a href="http://www.artisteer.com/?p=wordpress_themes">WordPress Theme</a> created with Artisteer.</p>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
        </div>
    </div>
</div>

</body>
</html>