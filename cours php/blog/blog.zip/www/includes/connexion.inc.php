<?php
mysql_connect('localhost','root','root');
mysql_select_db('blog2');
	/*try{
		$bdd = new PDO('mysql:host=localhost;dbname=blog2', 'root','root');
	}
	catch(Exception $e){
		die('Erreur : '.$e->getMessage());
	}*/
?>