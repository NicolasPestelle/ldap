<?php
setcookie('foo','bar',time()+60);
?>