<?php
mysql_connect('localhost','root','root');
mysql_select_db('blog');
?>